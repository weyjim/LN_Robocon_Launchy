#ifdef 	__KEY_H
#define 	__KEY_H




void KEY_Init(void);

#endif
