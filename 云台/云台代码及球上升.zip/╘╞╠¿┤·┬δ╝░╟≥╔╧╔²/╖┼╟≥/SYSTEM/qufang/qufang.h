#ifndef __QUFANG_H
#define __QUFANG_H

#include "sys.h"

void TIM3_CH2_PWM_Init(u16 arr,u16 psc);
void duoji_claw_open(void);
void duoji_claw_close(void);

#endif

